export default function Button({children, ...props}: any) {
  return <button {...props} style={{padding: '8px 12px', borderRadius: 6}}>{children}</button>;
}
