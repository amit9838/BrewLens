export default function Hero() {
  return (
    <section style={{padding: '48px 12px', textAlign: 'center'}}>
      <h1 style={{fontSize: 32, marginBottom: 8}}>BrewLens</h1>
      <p>Explore Homebrew Casks and Formulas in a beautiful UI.</p>
    </section>
  );
}
