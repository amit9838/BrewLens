export default function FeatureGrid() {
  return (
    <section style={{display:'grid', gridTemplateColumns:'repeat(auto-fit,minmax(220px,1fr))', gap:16, padding: 12}}>
      <div style={{padding:12, border:'1px solid #eee', borderRadius:8}}>
        <h3>Search</h3>
        <p>Find formulas and casks quickly.</p>
      </div>
      <div style={{padding:12, border:'1px solid #eee', borderRadius:8}}>
        <h3>Install</h3>
        <p>Copy install commands in one click.</p>
      </div>
      <div style={{padding:12, border:'1px solid #eee', borderRadius:8}}>
        <h3>Contribute</h3>
        <p>Open source and welcoming.</p>
      </div>
    </section>
  );
}
