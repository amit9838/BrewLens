import { Link } from "react-router-dom";
import NavDrawer from "./NavDrawer";

export default function Header() {
  return (
    <header style={{position: 'fixed', top: 0, left:0, right:0, height: 64, background: '#fff', boxShadow: '0 1px 4px rgba(0,0,0,0.08)', zIndex: 50}}>
      <div style={{maxWidth: 1100, margin: '0 auto', display: 'flex', alignItems: 'center', justifyContent: 'space-between', height: '100%', padding: '0 12px'}}>
        <Link to="/" style={{fontWeight: 700, textDecoration: 'none'}}>BrewLens</Link>
        <nav style={{display: 'flex', gap: 12, alignItems: 'center'}}>
          <Link to="/install">Install</Link>
          <Link to="/contribute">Contribute</Link>
          <Link to="/working">Working</Link>
          <NavDrawer />
        </nav>
      </div>
    </header>
  );
}
