import { useState } from "react";
import { Link } from "react-router-dom";

export default function NavDrawer() {
  const [open, setOpen] = useState(false);
  return (
    <>
      <button onClick={() => setOpen(o => !o)} aria-label="menu">☰</button>
      {open && (
        <div style={{position: 'fixed', top: 64, right: 12, width: 240, background:'#fff', boxShadow:'0 4px 20px rgba(0,0,0,0.12)', borderRadius:8, padding:12}}>
          <button onClick={() => setOpen(false)} style={{float:'right'}}>✕</button>
          <ul style={{listStyle:'none', padding:0}}>
            <li><Link to="/" onClick={() => setOpen(false)}>Home</Link></li>
            <li><Link to="/install" onClick={() => setOpen(false)}>Install</Link></li>
            <li><Link to="/contribute" onClick={() => setOpen(false)}>Contribute</Link></li>
            <li><Link to="/working" onClick={() => setOpen(false)}>Working</Link></li>
          </ul>
        </div>
      )}
    </>
  );
}
