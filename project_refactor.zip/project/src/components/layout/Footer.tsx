export default function Footer() {
  return (
    <footer style={{borderTop: '1px solid #eee', marginTop: 40, padding: 20, textAlign: 'center'}}>
      <div style={{maxWidth: 1100, margin: '0 auto'}}>© BrewLens • Built with ♥</div>
    </footer>
  );
}
