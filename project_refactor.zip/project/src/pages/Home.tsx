import Hero from "../components/home/Hero";
import FeatureGrid from "../components/home/FeatureGrid";

export default function Home() {
  return (
    <div className="container">
      <Hero />
      <FeatureGrid />
    </div>
  );
}
