export default function InstallGuide() {
  return (
    <div className="container" style={{padding: 24, maxWidth: 900, margin: '0 auto'}}>
      <h1>Installation Guide</h1>

      <h2>macOS</h2>
      <pre>brew install &lt;package-name&gt;</pre>

      <h2>Linux</h2>
      <pre>brew install &lt;package-name&gt;</pre>

      <h2>Notes</h2>
      <p>See the README in the repository for advanced instructions.</p>
    </div>
  );
}
