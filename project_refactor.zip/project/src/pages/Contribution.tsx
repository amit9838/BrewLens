export default function Contribution() {
  return (
    <div className="container" style={{padding: 24, maxWidth: 900, margin: '0 auto'}}>
      <h1>Contributing</h1>
      <p>Thanks for wanting to contribute! Steps:</p>
      <ol>
        <li>Fork the repository</li>
        <li>Create a topic branch</li>
        <li>Commit and open a Pull Request</li>
      </ol>
      <h2>Guidelines</h2>
      <p>Follow code style, write tests, update docs.</p>
    </div>
  );
}
