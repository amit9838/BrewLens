export default function Working() {
  return (
    <div className="container" style={{padding: 24, maxWidth: 900, margin: '0 auto'}}>
      <h1>How it works</h1>
      <p>This page explains high level architecture and data flow.</p>
      <ul>
        <li>Fetch metadata from Brew registries</li>
        <li>Index and display information</li>
        <li>Provide install commands and links</li>
      </ul>
    </div>
  );
}
