import { Routes, Route } from "react-router-dom";
import Home from "../pages/Home";
import InstallGuide from "../pages/InstallGuide";
import Contribution from "../pages/Contribution";
import Working from "../pages/Working";

export default function AppRoutes() {
  return (
    <Routes>
      <Route path="/" element={<Home />} />
      <Route path="/install" element={<InstallGuide />} />
      <Route path="/contribute" element={<Contribution />} />
      <Route path="/working" element={<Working />} />
    </Routes>
  );
}
