Refactor summary
- App.tsx slimmed to layout only
- Added routes/AppRoutes.tsx
- New pages: InstallGuide, Contribution, Working
- New components under components/layout and components/home
